import 'dotenv/config';
import fs from 'fs';
import path from 'path';

import { CodeReviewOrchestrator } from './orchestrator';
import { ReportGenerator } from './utils/report-generator';





async function main() {
  const [owner, repo, prStr] = process.argv.slice(2);

  if (!owner || !repo || !prStr || Number.isNaN(Number(prStr))){
    console.error('Usage: npm run dev <owner> <repo> <pr-number>');
    process.exit(1);
  }

  const prNumber = Number(prStr);

  if (!Number.isInteger(prNumber) || prNumber <=0) {
    console.error('Error: PR number must be a positive integer. ');
    process.exit(1);
  }



  const hasAnthropicAuth = Boolean(process.env.ANTHROPIC_API_KEY);

  const hasAwsAuth = Boolean(
    process.env.AWS_ACCESS_KEY_ID &&
    process.env.AWS_SECRET_ACCESS_KEY,
  );

  if (hasAwsAuth) {
    if (!process.env.AWS_REGION) {
      console.error(
        'Error: AWS_REGION is required when using AWS Bedrock authentication.',
      );
      process.exit(1);
    }
    console.log('Using AWS Bedrock authentication');
  } else if (hasAnthropicAuth) {
    console.log('Using Anthropic AOI authentication');
  } else {
    console.error(
      'Error: Authentication not configured. Set ANTHROPIC_API_KEY, or set AWS_ACCESS_KEY_ID + AWS_SECRET_ACCESS_KEY + AWS_REGION for AWS Bedrock.',
    );
    process.exit(1);
  }


  if(!process.env.ANTHROPIC_MODEL) {
    console.error(
      'Error: ANTHROPIC_MODEL environment variable is required.',
    );
    process.exit(1);
  }

  console.log(`Reviewing PR #${prNumber} for ${owner}/${repo}....`);

  try {
    const orchestrator = new CodeReviewOrchestrator();

    const report = await orchestrator.reviewPullRequest(
      owner,
      repo,
      prNumber,
    );

    const reportGenerator = new ReportGenerator();

    const jsonReport = reportGenerator.generateJSONReport(report);
    const markdownReport = reportGenerator.generateMarkdownReport(report);
    const htmlReport = reportGenerator.generateHTMLReport(report);
  

  const reportsDir = path.resolve('reports');
  fs.mkdirSync(reportsDir, { recursive: true});

  const baseName = `${owner}_${repo}_${prNumber}`;

  fs.writeFileSync(
    path.join(reportsDir, `${baseName}.json`),
    jsonReport,
    'utf-8',
  );

  fs.writeFileSync(
    path.join(reportsDir, `${baseName}.md`),
    markdownReport,
    'utf-8',
  );

  fs.writeFileSync(
    path.join(reportsDir, `${baseName}.html`),
    htmlReport,
    'utf-8',
  );

  console.log('\nReview complete. Reports saved:');
  console.log(`JSON: reports/${baseName},json`);
  console.log(`Markdown: reports/${baseName}.md`);
  console.log(`HTML: reports/${baseName}.html`);

  if (typeof report.summary.overallScore === 'number'){
    console.log(`Overall score: ${report.summary.overallScore}/100`);
   }
  }catch(error) {
    console.error(
      'Error:',
      error instanceof Error ? error.message : error,
    );
    process.exit(1);
  }
  }
  main();


  