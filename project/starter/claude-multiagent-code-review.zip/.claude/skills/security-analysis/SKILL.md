---
name: security-analysis
description: Security-focused code review guidance covering OWASP top 10, secure coding practices, and common security vulnerabilities.

# Security Analysis

Use this skill when reviewing code for security vulnerabilities and secure coding practices.

## OWSP TOP 10

Check for common vulnerabilities including:

- Broken access control
- Cryptographic failures
- Injection vulnerabilities
- Insecure design
- Security misconfiguration
- Vulnerable or outdated depedencies
- Authentication failures
- Software and data integrity failures
- Logging and monitoring weaknesses
- Server-side request forgery (SSRF)

## Secure Coding Practices

Look for:

- Hardcoded passwords, API keys, or secrets
- Unsafe handling of user input
- SQL injection
- Command injection
- Cross-site scripting (XSS)
- Path traversal
- Insecure file operations
- Weak authentication or authorization
- Sensitive information exposed in logs
- Missing input validation
- Unsafe deserialization

## Review Guidance

For every siginificant security issue, provide:

- File path 
- Line number when available
- Severity: critical, high, mediumm or low
- Explanation of thw security risk
- Suggested fix
- Example code when usefull

## Output

Return concise, actionable security findings. Prioritize vulnerabilities that cloud expose sensitive data, allow unauthorized access, execute malicious code or compromise application integrity.
