---
name : typescript-patterns
description: TypeScript-specific code review guidance covering type safety, advanced patterns, and common type issues.
---

# TypeScript Patterns

Use this skill when reviewing TypeScript or TSX code.

## Type Safety Best Practices

- Prefer explicit and meaningful types for public APIs.
- Avoid `any` when a safer types for can be used.
- Use `unknown` insted of `any` for values whose type is not know.
- Use union types and type guards for values with multiple possible shapes.
- Avoid unnecessary type assertions such as `as any`.
- Keep function parameters and return types clear.

# Advanced TypeScript Patterns

Look for appropriate use of

- Union and intersection types
- Generics
- Type guards
- Discriminated unions
- Utility types such as `Pick`, `Omit`, `Partial`, and `Record`
- Readonly types
- Interfaces and type aliases where appropriate

## Common Type Issues

Check for:

- Unsafe `any` usage
- Incorrect type assertions
- Missing null or undefined checks
- Inconsistent dunction return types
- Overly broad types
- Duplicate or conlicting type definitions 
- Unsafe access to object properties
- Missing validation of external data

## Review Guidance

For every significant issues, provide:
- File path
- Line number when avilable
- Severity: critical, hig, medium, or low
- Explanation of the type-safety problem
- Example code when usefull

## Output

Return concise, actionable TypeScript findings, Prioritize issues that can cause runtime errors, incorrect assumptions, or difficult-to-maintain code.
